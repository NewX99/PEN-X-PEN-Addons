
GuidelimeDataChar = {
	["mainFrameHeight"] = 400,
	["showUnavailableSteps"] = true,
	["guideSkip"] = {
		["Hakurai - by Shikushiku 中文由Qcat汉化 36-37 凄凉之地"] = {
		},
		["Hakurai - by Shikushiku 中文由Qcat汉化 33-36 荆棘谷"] = {
		},
	},
	["arrowY"] = -20,
	["arrowRelative"] = "TOP",
	["mainFrameX"] = 0,
	["mainFrameLocked"] = false,
	["mainFrameWidth"] = 350,
	["arrowLocked"] = false,
	["editorFrameY"] = 0,
	["showCompletedSteps"] = false,
	["arrowAlpha"] = 0.8,
	["arrowSize"] = 64,
	["mainFrameAlpha"] = 0.5,
	["currentGuide"] = "Hakurai - by Shikushiku 中文由Qcat汉化 33-36 荆棘谷",
	["mainFrameY"] = 0,
	["arrowX"] = 0,
	["mainFrameFontSize"] = 14,
	["mainFrameShowScrollBar"] = true,
	["version"] = "1.019",
	["editorFrameRelative"] = "CENTER",
	["guideSize"] = {
		["Hakurai - by Shikushiku 中文由Qcat汉化 36-37 凄凉之地"] = 140,
		["Hakurai - by Shikushiku 中文由Qcat汉化 33-36 荆棘谷"] = 161,
	},
	["mainFrameShowing"] = false,
	["showArrow"] = true,
	["mainFrameRelative"] = "RIGHT",
	["editorFrameX"] = 0,
}
