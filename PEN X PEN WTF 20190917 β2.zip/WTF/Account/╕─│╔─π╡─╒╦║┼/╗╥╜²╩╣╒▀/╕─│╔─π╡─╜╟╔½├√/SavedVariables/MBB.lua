
MBB_Exclude = {
}
MBB_Options = {
	["CollapseTimeout"] = 2.29243731498718,
	["AltExpandDirection"] = 4,
	["AttachToMinimap"] = 1,
	["DetachedButtonPos"] = "TOPLEFT",
	["MaxButtonsPerLine"] = 0,
	["ButtonPos"] = {
		131.704864501953, -- [1]
		-74.1453475952149, -- [2]
	},
	["ExpandDirection"] = 1,
}
