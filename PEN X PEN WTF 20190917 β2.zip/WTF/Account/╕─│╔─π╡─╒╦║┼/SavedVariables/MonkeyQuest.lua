
MonkeyQuestConfig = {
	["Global"] = {
		["m_bItemsEnabled"] = false,
		["m_iFont"] = 2,
		["m_strHeaderClosedColour"] = "|cFF9F9FFF",
		["m_strSpecialObjectiveColour"] = "|cFFFFFF00",
		["m_iFrameAlpha"] = 1,
		["m_bColourTitle"] = false,
		["m_strAnchor"] = "ANCHOR_TOPLEFT",
		["m_bAllowRightClick"] = true,
		["m_strZoneHighlightColour"] = "|cff494961",
		["m_strFinishObjectiveColour"] = "|cFF33DDFF",
		["m_bShowHidden"] = false,
		["m_bItemsOnLeft"] = true,
		["m_bShowNoobTips"] = true,
		["m_bHideCompletedObjectives"] = true,
		["m_bShowZoneHighlight"] = false,
		["m_strCompleteObjectiveColour"] = "|cFF00FF19",
		["m_bAlwaysHeaders"] = false,
		["m_bDisplay"] = true,
		["m_bMinimized"] = true,
		["m_strInitialObjectiveColour"] = "|cFFD82619",
		["m_iHighlightAlpha"] = 1,
		["m_bShowQuestLevel"] = true,
		["m_bShowDailyNumQuests"] = false,
		["m_iFrameBottom"] = 677.930053710938,
		["m_bHideCompletedQuests"] = true,
		["m_iFrameLeft"] = 1469.07946777344,
		["m_bColourDoneOrFailed"] = false,
		["m_bLocked"] = false,
		["m_bNoBorder"] = true,
		["m_bNoHeaders"] = true,
		["m_iAlpha"] = 0,
		["m_strOverviewColour"] = "|cFF7F7F7F",
		["m_bShowNumQuests"] = false,
		["m_bColourSubObjectivesByProgress"] = true,
		["m_strMidObjectiveColour"] = "|cFFFFFF00",
		["m_iFontHeight"] = 12,
		["m_strQuestTitleColour"] = "|cFFFFFFFF",
		["m_bWorkComplete"] = true,
		["m_bHideQuestsEnabled"] = true,
		["m_iFrameWidth"] = 204,
		["m_bCrashBorder"] = false,
		["m_strHeaderOpenColour"] = "|cFFBFBFFF",
		["m_iFrameTop"] = 703.930053710938,
		["m_bObjectives"] = true,
		["m_bHideHeader"] = false,
		["m_bShowTooltipObjectives"] = true,
		["m_iQuestPadding"] = 0,
		["m_bShowQuestTextTooltip"] = false,
		["m_bHideTitle"] = true,
		["m_bHideTitleButtons"] = false,
		["m_bGrowUp"] = false,
	},
	["灰烬使者|Mavis"] = {
		["m_aQuestList"] = {
			["拉泽瑞克的调整 - false"] = {
				["m_bChecked"] = true,
			},
			["收集鳄鱼皮 - false"] = {
				["m_bChecked"] = true,
			},
			["失而复得 - false"] = {
				["m_bChecked"] = true,
			},
			["奥达曼 - true"] = {
				["m_bChecked"] = true,
			},
			["血色修道院 - true"] = {
				["m_bChecked"] = true,
			},
			["克拉兹克的要求 - false"] = {
				["m_bChecked"] = true,
			},
			["以圣光之名 - false"] = {
				["m_bChecked"] = true,
			},
			["暴风城 - true"] = {
				["m_bChecked"] = true,
			},
			["匹瑞诺德王冠 - false"] = {
				["m_bChecked"] = true,
			},
			["梦境之尘 - false"] = {
				["m_bChecked"] = true,
			},
			["泰坦神话 - false"] = {
				["m_bChecked"] = true,
			},
			["荒芜之地 - true"] = {
				["m_bChecked"] = true,
			},
			["猎龙 - false"] = {
				["m_bChecked"] = true,
			},
			["荆棘谷 - true"] = {
				["m_bChecked"] = true,
			},
			["寻找阿戈莫德 - false"] = {
				["m_bChecked"] = true,
			},
			["流放者马特克 - false"] = {
				["m_bChecked"] = true,
			},
			["巨魔巫术 - false"] = {
				["m_bChecked"] = true,
			},
			["千针石林 - true"] = {
				["m_bChecked"] = true,
			},
			["水元素 - false"] = {
				["m_bChecked"] = true,
			},
		},
	},
}
