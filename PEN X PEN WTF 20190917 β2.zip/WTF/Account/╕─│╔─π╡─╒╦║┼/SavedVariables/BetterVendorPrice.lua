
betterVendorPriceSaved = {
	["addonVersion"] = "v1.08.00-classic",
	["showFullStack"] = true,
	["addonHash"] = "1b9de11",
}
