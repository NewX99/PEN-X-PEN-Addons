
DecursiveDB = {
	["global"] = {
		["NonRelease"] = "2.7.6.4-beta_3",
		["LastVersionAnnounce"] = 1568614714,
		["NewerVersionAlert"] = 1568092620,
	},
	["class"] = {
		["WARLOCK"] = {
			["CureOrder"] = {
				-12, -- [1]
				-13, -- [2]
				nil, -- [3]
				-14, -- [4]
				[8] = -15,
				[16] = -16,
				[32] = 1,
			},
		},
	},
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["DebuffsFrameContainer_y"] = 494.933301437378,
			["MainBarX"] = 682.666681134258,
			["MainBarY"] = -96.0000020345051,
			["ShowDebuffsFrame"] = false,
			["DebuffsFrameContainer_x"] = 1024.00005523681,
		},
	},
}
