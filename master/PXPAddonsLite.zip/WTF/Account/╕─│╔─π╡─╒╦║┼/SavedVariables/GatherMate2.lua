
GatherMate2DB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Default",
	},
	["global"] = {
		["data_version"] = 5,
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
GatherMate2HerbDB = {
}
GatherMate2MineDB = {
	[1431] = {
		[7410800000] = 203,
		[3353441300] = 201,
		[7204757200] = 203,
		[3053714200] = 202,
		[2786348100] = 201,
		[2589338400] = 203,
		[3462777000] = 202,
	},
	[1441] = {
		[6288606800] = 202,
		[8335530300] = 203,
		[1961260600] = 202,
		[8651843000] = 203,
	},
	[1445] = {
		[5220497000] = 202,
	},
}
GatherMate2FishDB = {
}
GatherMate2GasDB = nil
GatherMate2TreasureDB = {
	[1431] = {
		[3320693400] = 504,
		[3468546700] = 504,
	},
}
GatherMate2ArchaeologyDB = nil
GatherMate2LoggingDB = nil
