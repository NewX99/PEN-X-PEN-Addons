
alaBaseData = {
	["xBtn"] = {
		["posEx"] = "BELOW_EDITBOX",
		["scale"] = 1,
		["alpha"] = 1,
		["_version"] = 1.06,
		["pos"] = {
			"TOPLEFT", -- [1]
			"ChatFrame1EditBox", -- [2]
			"BOTTOMLEFT", -- [3]
			0, -- [4]
			-1, -- [5]
		},
	},
}
alaChatConfig = {
	["scale"] = 1,
	["ReadyCheck"] = false,
	["shortChannelName"] = true,
	["bfWorld_Ignore_BtnSize"] = 28,
	["channelBarChannel"] = {
		false, -- [1]
		false, -- [2]
		false, -- [3]
		false, -- [4]
		false, -- [5]
		false, -- [6]
		false, -- [7]
		false, -- [8]
		false, -- [9]
		false, -- [10]
		false, -- [11]
		false, -- [12]
		false, -- [13]
		false, -- [14]
	},
	["filterQuestAnn"] = false,
	["bfWorld_Ignore_Switch"] = false,
	["restoreAfterWhisper"] = true,
	["level"] = true,
	["_version"] = 190910,
	["copyTagColor"] = {
		0.25, -- [1]
		0.25, -- [2]
		1, -- [3]
	},
	["shamanColor"] = false,
	["ColorNameByClass"] = true,
	["position"] = "BELOW_EDITBOX",
	["welcomeToGuild"] = false,
	["editBoxTab"] = true,
	["chatEmote"] = false,
	["alpha"] = 1,
	["roll"] = false,
	["channelBarStyle"] = "CHAR",
	["welcometoGuildMsg"] = "欢迎",
	["hyperLinkHoverShow"] = false,
	["itemLinkEnhanced"] = true,
	["DBMCountDown"] = false,
	["copy"] = true,
	["broadCastNewMember"] = false,
	["bfWorld_Ignore"] = false,
}
