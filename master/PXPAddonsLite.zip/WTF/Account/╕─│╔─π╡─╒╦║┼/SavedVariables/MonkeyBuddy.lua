
MonkeyBuddyConfig = {
	["Global"] = {
		["m_bDismissed"] = true,
		["m_bDailies"] = false,
	},
}
