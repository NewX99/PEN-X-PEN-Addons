
BADBOY_BLACKLIST = {
	["dayFromCal"] = 16,
}
BADBOY_OPTIONS = {
}
