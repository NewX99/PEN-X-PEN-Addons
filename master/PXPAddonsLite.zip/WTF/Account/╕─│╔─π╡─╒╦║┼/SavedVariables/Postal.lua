
Postal3DB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Mavis|灰烬使者|Alliance|38|WARLOCK", -- [1]
			},
		},
	},
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
			["BlackBook"] = {
				["recent"] = {
					"大丁叔叔|灰烬使者|Alliance", -- [1]
					"丶会长丶|灰烬使者|Alliance", -- [2]
				},
			},
		},
	},
}
