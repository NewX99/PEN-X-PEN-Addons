
AtlasLootClassicDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["global"] = {
		["__addonrevision"] = 1010011,
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"Ragefire", -- [2]
					nil, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
		},
	},
}
