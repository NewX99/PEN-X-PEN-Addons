
Bartender4DB = {
	["namespaces"] = {
		["BagBar"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["Mavis - 灰烬使者"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 29.4000048398971,
						["x"] = -133.000157847353,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.699999988079071,
					},
					["fadeout"] = true,
					["padding"] = 0,
					["fadeoutalpha"] = 0,
				},
				["Mavis - 埃提耶什"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 62,
					},
				},
				["诺曼 - 灰烬使者"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["y"] = 62,
						["x"] = 33,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 62,
					},
				},
				["Mavis - 灰烬使者"] = {
					["enabled"] = false,
					["position"] = {
						["y"] = 50.8000437359024,
						["x"] = -171.999918018004,
						["point"] = "CENTER",
						["scale"] = 0.800000011920929,
					},
					["version"] = 3,
				},
				["Mavis - 埃提耶什"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["y"] = 62,
						["x"] = 33,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["Mavis - 埃提耶什"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["ActionBars"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -205,
								["x"] = -231.499938964844,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["诺曼 - 灰烬使者"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -205,
								["x"] = -231.499938964844,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -205,
								["x"] = -231.499938964844,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["Mavis - 灰烬使者"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41,
								["x"] = -246.178894042969,
								["point"] = "BOTTOM",
							},
							["padding"] = 0,
							["states"] = {
								["actionbar"] = true,
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -162.867340087891,
								["x"] = -231.5,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 150.050018310547,
								["x"] = -205.267791748047,
								["point"] = "BOTTOM",
							},
						}, -- [3]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41,
								["x"] = 187.301513671875,
								["point"] = "BOTTOM",
							},
							["padding"] = 0,
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 79,
								["x"] = 187.821228027344,
								["point"] = "BOTTOM",
							},
							["padding"] = 0,
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 79,
								["x"] = -246.178894042969,
								["point"] = "BOTTOM",
							},
							["padding"] = 0,
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["Mavis - 埃提耶什"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -205,
								["x"] = -231.499938964844,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["Mavis - 灰烬使者"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 9.10807037353516,
						["x"] = 3.46742343902588,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.5,
					},
					["version"] = 3,
				},
				["Mavis - 埃提耶什"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
				},
				["Mavis - 灰烬使者"] = {
					["position"] = {
						["y"] = -15,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
					["version"] = 3,
				},
				["Mavis - 埃提耶什"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 143,
						["x"] = -120,
						["point"] = "BOTTOM",
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["Mavis - 灰烬使者"] = {
					["fadeoutalpha"] = 1,
					["position"] = {
						["y"] = 41.0989303588867,
						["x"] = 191.839782714844,
						["point"] = "BOTTOMLEFT",
					},
					["visibility"] = {
						["nopet"] = false,
						["overridebar"] = false,
						["vehicle"] = false,
						["vehicleui"] = false,
					},
					["version"] = 3,
				},
				["Mavis - 埃提耶什"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["RepBar"] = {
			["profiles"] = {
				["WARLOCK"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["诺曼 - 灰烬使者"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["米尔豪丝 - 秩序之源"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["Mavis - 灰烬使者"] = {
					["position"] = {
						["y"] = 4.99996948242188,
						["x"] = 246.518508911133,
						["point"] = "LEFT",
					},
					["version"] = 3,
				},
				["Mavis - 埃提耶什"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["米尔豪丝 - 秩序之源"] = "米尔豪丝 - 秩序之源",
		["诺曼 - 灰烬使者"] = "诺曼 - 灰烬使者",
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
		["Mavis - 埃提耶什"] = "Mavis - 埃提耶什",
	},
	["profiles"] = {
		["WARLOCK"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["诺曼 - 灰烬使者"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["米尔豪丝 - 秩序之源"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["Mavis - 灰烬使者"] = {
			["minimapIcon"] = {
				["minimapPos"] = 57.3203180979365,
			},
			["snapping"] = false,
		},
		["Mavis - 埃提耶什"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
	},
}
