
QuestLogExDB = {
	["profileKeys"] = {
		["Mavis - 灰烬使者"] = "Mavis - 灰烬使者",
	},
	["profiles"] = {
		["Mavis - 灰烬使者"] = {
		},
	},
}
