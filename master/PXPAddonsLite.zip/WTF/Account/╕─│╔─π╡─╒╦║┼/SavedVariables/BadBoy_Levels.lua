
BADBOY_LEVELS = {
	["allowfriends"] = false,
	["dklevel"] = 58,
	["dhlevel"] = 100,
	["allowgroup"] = false,
	["level"] = 3,
	["blockall"] = false,
	["allowguild"] = false,
}
