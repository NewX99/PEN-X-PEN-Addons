
ChatBar_VerticalDisplay = false
ChatBar_AlternateOrientation = false
ChatBar_HideSpecialChannels = true
ChatBar_TextOnButtonDisplay = false
ChatBar_ButtonFlashing = true
ChatBar_BarBorder = true
ChatBar_ButtonText = false
ChatBar_StoredStickies = {
}
ChatBar_HiddenButtons = {
}
ChatBar_TextChannelNumbers = false
ChatBar_HideAllButtons = nil
ChatBar_AltArt = 2
ChatBar_ChannelBindings = {
}
ChatBar_ButtonScale = 1
